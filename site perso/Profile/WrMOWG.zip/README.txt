A Pen created at CodePen.io. You can find this one at http://codepen.io/littlesnippets/pen/WrMOWG.

 Profile Card with image and icons