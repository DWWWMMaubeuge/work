<?php


function footer()
{
$str  =<<<AZE
 <footer class="footer">
<div class="container">
<div class="row">
    <div class="col-md-3 mt-md-0 mt-3">
<a href="#">
<img class="img-fluid" src="./Images/Images_Charte_Graphique/logo_ozinor_propo_SIMPLE_v2.png"  style="height: 200px">
</a>
</div>
<hr class="clearfix w-100 d-md-none pb-3">
    <div class="col-md-3 mb-md-0 mb-3">
    <h4 class="footer__title">Socials</h4>
<ul class="list-unstyled">
<li>
<a href="#!">Facebook</a>
</li>
<li>
<a href="https://www.linkedin.com/feed/"target="_blank">LinkedIn</a>
</li>
<li>
<a href="https://github.com/nicolascaulier" target="_blank">GitHub</a>
</li>
<li>
<a href="#!">Twitter</a>
</li>
</ul>
</div>
<div class="col-md-3 mb-md-0 mb-3">
<h4 class="footer__title">Structure</h4>
<ul class="list-unstyled">
<li>
<a href="#!">New</a>
</li>
<li>
<a href="#!">Staff</a>
</li>
<li>
<a href="#!">About us</a>
</li>
</ul>
</div> 
<div class="col-md-3 mb-md-0 mb-3">
<h4 class="footer__title">Plus</h4>
<ul class="list-unstyled">
<li>
<a href="#!">Mentions légales</a>
</li>
<li>
 <a href="#!">Contact</a>
</li>
</ul>
</div>
</div>
<div class="separator"></div>
</div>
    
<div class="text_footer ">
 © 2020 Nicolas Caulier tous droits réservés
</div>
   </footer>

AZE;
return $str;



}
?>