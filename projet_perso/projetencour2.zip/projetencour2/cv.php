<?php

include "header.php";
echo entete();
include "navbar.php";
echo nav();

?>
<style>
    background-image{ Noir et Blanc Stockholm voyage Instagram publication.jpg
</style>