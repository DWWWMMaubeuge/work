# work
Voici le repos GIT sur lequel vous pouvez remonter vos travaux.
Je push sur master

Créez vous un branche perso.
Travaillez sur cette branche perso.
Pour récupérer ce que je push, faites un pull, placez-vous sur votre branche et,mergez y le contenu de master.
Quand votre travail est OK, pushez-le sur votre branche perso.
